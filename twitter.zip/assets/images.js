const images = {
    image1: require('./avatar1.png'),
    image2: require('./avatar2.png'),
    image3: require('./avatar3.png'),
    image4: require('./heeseung.jpg'),
    image5: require('./plat.png'),
};

export default images;