import React, { Component } from 'react';
import { url } from '../constants';
import { FontAwesome } from '@expo/vector-icons';
import StatusContainer from '../components/StatusContainer';


class StatusListScreen extends Component {
  constructor(props) {
    super(props)
    this.state = {
        data: [],
    }
  }
  componentWillMount() {
    this.getStatusList();
  }

  getStatusList = async ()=> {
      fetch(url+'/story', {
          headers: {
            'Accept': 'application/json'
          }
        })
      .then(res => res.json())    
      .then(json => {
          this.setState({ data: json })
      })
      .catch(err =>
        console.error(err)
      )
    };

  render() {
      return <StatusContainer data={this.state.data}/>
  }
};

StatusListScreen.navigationOptions = {
  title: 'My Story',
  tabBarIcon: <FontAwesome name="th-list" size={20} />
};

export default StatusListScreen;
