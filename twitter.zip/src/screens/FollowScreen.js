import React, { Component } from 'react';
import { FlatList, TouchableOpacity, AsyncStorage, Text } from 'react-native';
import { url } from '../constants';
import { navigate } from '../navigationRef';



class FollowScreen extends Component {
  constructor(props) {
    super(props)
    this.state = {
        user: "",
        followers: [],
        followees: [],
    }
}
  // const status = navigation.getParam('status');
  // const user = navigation.getParam('user');
  // let user = "";
  // let status = "";

  componentWillMount() {
    this.getUserFollower();
  }

  getUserFollower = () => {
    AsyncStorage.getItem("selectedUser")
    .then(res => {
      this.setState({ user: res })
    }).then(this.getFollowers())
    .then(this.getFollowees());
  }

  getFollowers = async ()=> {
    fetch(url+'/followers', {
        headers: {
          'Accept': 'application/json'
        }
      })
    .then(res => res.json())    
    .then(json => {
        this.setState({ followers: json })
    })
    .catch(err =>
      console.error(err)
    )
  };

  getFollowees = async ()=> {
    fetch(url+'/followees', {
        headers: {
          'Accept': 'application/json'
        }
      })
    .then(res => res.json())    
    .then(json => {
        this.setState({ followees: json })
    })
    .catch(err =>
      console.error(err)
    )
  };

  
  render() {
    return (
      <>
        <Text>Followers:</Text>
        <FlatList
          style={{
            flex: 1,
            width: '100%',
          }}
          data={this.state.followers}
          keyExtractor={item => item.id}
          renderItem={({ item }) => {
            return(
              <TouchableOpacity onPress={() => navigate('Story', {alias: item.alias})}>
                <Text>{item.alias}</Text>
              </TouchableOpacity>
            )
          }}
        />
        <Text>Followees:</Text>
        <FlatList
          style={{
            flex: 1,
            width: '100%',
          }}
          data={this.state.followees}
          keyExtractor={item => item.id}
          renderItem={({ item }) => {
            return(
              <TouchableOpacity onPress={() => navigate('Story', {alias: item.alias})}>
                <Text>{item.alias}</Text>
              </TouchableOpacity>
            )
          }}
        />
      </>
    );
  }
};


export default FollowScreen;
