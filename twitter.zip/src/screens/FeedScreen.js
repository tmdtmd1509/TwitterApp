import React, { Component } from 'react';
import { FontAwesome } from '@expo/vector-icons';
import { url } from '../constants';
import { View, Text } from "react-native";
import StatusContainer from '../components/StatusContainer';


class FeedScreen extends Component {
  constructor(props) {
    super(props)
    this.state = {
        data: [],
    }
  }
  componentWillMount() {
      this.getFeed();
  }

  getFeed = async ()=> {
      fetch(url+'/feed', {
          headers: {
            'Accept': 'application/json'
          }
        })
      .then(res => res.json())    
      .then(json => {
          this.setState({ data: json })
      })
      .catch(err =>
        console.error(err)
      )
    };


  render() {
      return <StatusContainer data={this.state.data}/>
  }
}

FeedScreen.navigationOptions = {
  title: 'Feeds',
  tabBarIcon: <FontAwesome name="th-list" size={20} />
};

export default FeedScreen;
