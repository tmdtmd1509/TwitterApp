import React, { useState } from 'react';
import { url } from '../constants';
import { View, Text, Button, TextInput } from 'react-native';
import { SafeAreaView } from 'react-navigation';
import Spacer from '../components/Spacer';
import { FontAwesome } from '@expo/vector-icons';



// const handleChange = (e) => {
//   this.setState({text: e.target.value});
// }

const CreateStatusScreen = () => {
  const [text, setText] = useState("Write your tweet");


  handleSubmit = () => {
      this.postStatus();
  }

  postStatus = () => {
    let status = {
        "id": "1",
        "alias": "test1",
        "text": "",
        "mention": "",
        "attachment": text,
        "hashtag":"",
        "url":"",
        "time": "2019.11.17 18:20",
    }

    fetch(url+'/status', {
      headers: {
        'Accept': 'application/json'
      },
      method: 'POST',
      body: JSON.stringify(status),
    })//.then(res => res.json())
    .then(data => alert("post status successfully"))
    .catch(err => console.error(err))
  };

  return (
    <SafeAreaView forceInset={{ top: 'always' }}>
      <Text style={{ fontSize: 20, fontWeight: 'bold' }}>Create a Tweet</Text>
        <TextInput
            style={{ height: 400, borderColor: 'gray', borderWidth: 1, margin: 10}}
            value={text}
            onChangeText={ setText }
        />
      <Spacer>
        <Button 
          title="Post" 
          onPress={() => this.handleSubmit()}
        />
      </Spacer>
    </SafeAreaView>
  );
};

CreateStatusScreen.navigationOptions = {
  title: 'Add Tweet',
  tabBarIcon: <FontAwesome name="plus" size={20} />
};

export default CreateStatusScreen;
