import React, { Component } from 'react';
import { FontAwesome } from '@expo/vector-icons';
import { url } from '../constants';
import { AsyncStorage } from 'react-native';
import StatusContainer from '../components/StatusContainer';


class StoryScreen extends Component {
  constructor(props) {
    super(props)
    this.state = {
        data: [],
        alias: "",
    }
  }
  componentWillMount() {
    AsyncStorage.getItem("selectedUser")
    // .then(res => {
    //   this.setState({ alias: res })
    // })
    .then(alias => console.log(alias))
    .then(res => this.getStory(res));
  }

  getStory = async (alias)=> {
      fetch(url+'/story/test2', {
          headers: {
            'Accept': 'application/json'
          }
        })
      .then(res => res.json())    
      .then(json => {
          this.setState({ data: json })
      })
      .then(res => console.log(res))
      .catch(err =>
        console.error(err)
      )
    };


  render() {
    console.log(this.state.data);
      return <StatusContainer data={this.state.data}/>
  }
}

StoryScreen.navigationOptions = {
  title: 'Story',
};

export default StoryScreen;
