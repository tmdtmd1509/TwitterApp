import { AsyncStorage } from 'react-native';
import createDataContext from './createDataContext';
import { navigate } from '../navigationRef';
import Images from '../../assets/images';
import { Auth } from 'aws-amplify';
//import {getFeed} from '../api/apiContext'


// import * as Permissions from 'expo-permissions';
// import * as MediaLibrary from 'expo-media-library';

const authReducer = (state, action) => {
  switch (action.type) {
    case 'add_error':
      return { ...state, errorMessage: action.payload };
    case 'signin':
      return { user: action.payload, errorMessage: '' };
    case 'clear_error_message':
      return { ...state, errorMessage: '' };
    case 'signout':
      return { user: null, errorMessage: '' };
    case 'reset':
      return { user: null, errorMessage: ''};
    default:
      return state;
  }
};

const status1 = {
  id: "1",
  alias: "test1",
  text: "tweet text example 1",
  mention: "",
  attachment: Images.image5,
  hashtag:"",
  url:"",
  time: "2019.10.7 18:20",
}

const status2 = {
  id: "2",
  alias: "test1",
  text: "tweet text example 2",
  mention: "",
  attachment: "",
  hashtag:"",
  url:"",
  time: "2019.10.7 18:20",
}

const status3 = {
  id: "3",
  alias: "test2",
  text: "tweet text example 3",
  mention: "",
  attachment: Images.image4,
  hashtag: "hashtag1",
  url:"",
  time: "2019.10.7 18:20",
}

const status4 = {
  id: "4",
  alias: "test3",
  text: "tweet text example 4",
  mention: "test1",
  attachment: "",
  hashtag: "hashtag1",
  url:"",
  time: "2019.10.7 18:20",
}
const status5 = {
  id: "5",
  alias: "test3",
  text: "tweet text example 5",
  mention: "test2",
  attachment: "",
  hashtag:"",
  url:"",
  time: "2019.10.7 18:20",
}

const user = {
  name: "",
  alias: "",
  password: "",
  picture: Images.image1,
  statuses: [status1, status2],
  followers: ["test2", "test3"]
}

const test2 = {
  name: "test2",
  alias: "test2",
  password: "a",
  picture: Images.image2,
  statuses: [status3],
  followers: ["test1"]
}

const test3 = {
  name: "test3",
  alias: "test3",
  password: "a",
  picture: Images.image3,
  statuses: [status4, status5],
  followers: ["test1"]
}


const tryLocalSignin = dispatch => async () => {
  const user = await AsyncStorage.getItem(alias);
  if (user) {
    dispatch({ type: 'signin', payload: user });
    navigate('StatusList');
  } else {
    navigate('Signup');
  }
};

const clearErrorMessage = dispatch => () => {
  dispatch({ type: 'clear_error_message' });
};

const signup = dispatch => async ({ name, alias, password, email, picture }) => {
  user.name = name,
  user.alias = alias,
  user.password = password,
  user.email = email,
  user.picture = picture

  try {
    const success = await Auth.signUp({
      username: name,
      alias: alias,
      password,
      picture: picture,
      attributes: { email },
      })
      //console.log('user successfully signed up!: ', success)
      dispatch({ type: 'signin', payload: user });
      await AsyncStorage.setItem("currentUser", JSON.stringify(user));

      navigate('Feed')
  } catch (err) {
    //console.log('error signing up: ', err)
    dispatch({ type: 'add_error', payload: err.message });
  }
};

const signin = dispatch => async ({ alias, password }) => {
  try {
    const user = await Auth.signIn(alias, password);
    dispatch({ type: 'signin', payload: user });
    await AsyncStorage.setItem("currentUser", JSON.stringify(user));

    navigate('Feed');
  } catch(err) {
    //console.log('error signing in: ', err)
    dispatch({ type: 'add_error', payload: err.message });
  }
};

const signout = dispatch => async () => {
  try {
    await Auth.signOut();
    await AsyncStorage.setItem("currentUser", "");
    navigate('loginFlow');
  } catch (err) {
    //console.log(err);
    dispatch({ type: 'add_error', payload: 'Something went wrong with sign out' });
  }
};

const reset = dispatch => async () => {
  await AsyncStorage.clear();
  dispatch({ type: 'clear' });
  navigate('loginFlow');
};


export const { Provider, Context } = createDataContext(
  authReducer,
  { signin, signout, signup, reset, clearErrorMessage, tryLocalSignin },
  // { signin, signout, signup, clearErrorMessage },
  { user: null, errorMessage: '' }
);
