export const url = "https://jnz7tnqn30.execute-api.us-west-2.amazonaws.com/11-5-2019";
export const s3url = "https://twitter-app-20191202.s3-us-west-2.amazonaws.com/picture/";
