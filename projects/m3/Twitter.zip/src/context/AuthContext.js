import { AsyncStorage } from 'react-native';
import createDataContext from './createDataContext';
import { navigate } from '../navigationRef';
import Images from '../../assets/images';

// import * as Permissions from 'expo-permissions';
// import * as MediaLibrary from 'expo-media-library';

const authReducer = (state, action) => {
  switch (action.type) {
    case 'add_error':
      return { ...state, errorMessage: action.payload };
    case 'signin':
      return { errorMessage: '', user: action.payload };
    case 'clear_error_message':
      return { ...state, errorMessage: '' };
    case 'signout':
      return { user: null, errorMessage: '' };
    case 'reset':
      return { user: null, errorMessage: ''};
    default:
      return state;
  }
};

const status1 = {
  id: "1",
  alias: "test1",
  text: "tweet text example 1",
  mention: "",
  attachment: Images.image5,
  hashtag:"",
  url:"",
  time: "2019.10.7 18:20",
}

const status2 = {
  id: "2",
  alias: "test1",
  text: "tweet text example 2",
  mention: "",
  attachment: "",
  hashtag:"",
  url:"",
  time: "2019.10.7 18:20",
}

const status3 = {
  id: "3",
  alias: "test2",
  text: "tweet text example 3",
  mention: "",
  attachment: Images.image4,
  hashtag: "hashtag1",
  url:"",
  time: "2019.10.7 18:20",
}

const status4 = {
  id: "4",
  alias: "test3",
  text: "tweet text example 4",
  mention: "test1",
  attachment: "",
  hashtag: "hashtag1",
  url:"",
  time: "2019.10.7 18:20",
}
const status5 = {
  id: "5",
  alias: "test3",
  text: "tweet text example 5",
  mention: "test2",
  attachment: "",
  hashtag:"",
  url:"",
  time: "2019.10.7 18:20",
}

const user = {
  name: "",
  alias: "",
  password: "",
  picture: Images.image1,
  statuses: [status1, status2],
  followers: ["test2", "test3"]
}

const test2 = {
  name: "test2",
  alias: "test2",
  password: "a",
  picture: Images.image2,
  statuses: [status3],
  followers: ["test1"]
}

const test3 = {
  name: "test3",
  alias: "test3",
  password: "a",
  picture: Images.image3,
  statuses: [status4, status5],
  followers: ["test1"]
}


const tryLocalSignin = dispatch => async () => {
  const user = await AsyncStorage.getItem(alias);
  if (user) {
    dispatch({ type: 'signin', payload: user });
    navigate('StatusList');
  } else {
    navigate('Signup');
  }
};

const clearErrorMessage = dispatch => () => {
  dispatch({ type: 'clear_error_message' });
};

const signup = dispatch => async ({ name, alias, password, picture }) => {
  try {
    // const response = await trackerApi.post('/signup', { name, password });

    await AsyncStorage.setItem("test2", JSON.stringify(test2));
    await AsyncStorage.setItem("test3", JSON.stringify(test3));


    if(await AsyncStorage.getItem(alias) == null) {
      // dispatch({ type: 'signin', payload: JSON.stringify(user) });
      user.name = name;
      user.alias = alias;
      user.password = password;
      // user.picture = picture;
      await AsyncStorage.setItem(alias, JSON.stringify(user));
      await AsyncStorage.setItem("currentUser", JSON.stringify(user));
      console.log(await AsyncStorage.getItem(alias));
      

      navigate('Feed');
    }
    else{
      dispatch({
        type: 'add_error',
        payload: 'alias already exist'
      });
    }
  } catch (err) {
    console.log(err);
    dispatch({
      type: 'add_error',
      payload: 'Something went wrong with sign up'
    });
  }
};

const signin = dispatch => async ({ alias, password }) => {
  try {
    // const response = await trackerApi.post('/signin', { name, password });
    const user = JSON.parse(await AsyncStorage.getItem(alias));
    if(user !== null) {
      if(user.password == password) {
        await AsyncStorage.setItem("currentUser", JSON.stringify(user));
        dispatch({ type: 'signin', payload: user });
        navigate('Feed');  
      }
      else {
        dispatch({
          type: 'add_error',
          payload: 'Incorrect password'
        });
      }
    }
    else {
      dispatch({
        type: 'add_error',
        payload: 'No such name exist'
      });
    }
  } catch (err) {
    dispatch({
      type: 'add_error',
      payload: 'Something went wrong with sign in'
    });
  }
};

const signout = dispatch => async () => {
  // await AsyncStorage.removeItem('token');
  dispatch({ type: 'signout' });
  navigate('loginFlow');
};

const reset = dispatch => async () => {
  await AsyncStorage.clear();
  dispatch({ type: 'clear' });
  navigate('loginFlow');
};

// const requestPermisison = dispatch = async () => {
//   const response = await Permissions.askAsync(Permissions.CAMERA);
//   console.log(response);
//   const { status } = await Permissions.getAsync(Permissions.CAMERA);
//   if(status !== 'granted') {
//     dispatch({
//       type: 'add_error',
//       payload: 'Camera permission denied'
//     });
//   }
// };




export const { Provider, Context } = createDataContext(
  authReducer,
  { signin, signout, signup, reset, clearErrorMessage, tryLocalSignin },
  // { signin, signout, signup, clearErrorMessage },
  { token: null, errorMessage: '' }
);
