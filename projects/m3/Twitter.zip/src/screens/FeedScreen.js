import React, { useContext, useState } from 'react';
import { AsyncStorage, StyleSheet, Text, FlatList, TouchableOpacity } from 'react-native';
import { NavigationEvents } from 'react-navigation';
// import { ListItem } from 'react-native-elements';
import { Context as StatusContext } from '../context/StatusContext';
import Status from '../components/Status'
import { FontAwesome } from '@expo/vector-icons';

const FeedScreen = ({ navigation }) => {
  const { state, fetchStatuses } = useContext(StatusContext);
  const [feed, setFeed] = useState([]);

  const getstatuses = async() => {
    var tempFeed = [];
    const user = JSON.parse(await AsyncStorage.getItem("currentUser"));
    user.followers.map(async (item) => {
        const userInfo = JSON.parse(await AsyncStorage.getItem(item));
        tempFeed.push(...userInfo.statuses);
    });

    console.log(tempFeed);
    setFeed(tempFeed);
  }

  return (
    <>
      <NavigationEvents onWillFocus={getstatuses} />
      <FlatList
        data={feed}
        keyExtractor={item => item.id}
        renderItem={({ item }) => {
          return (
            <TouchableOpacity
              onPress={() =>
                navigation.navigate('StatusDetail', {user: item.alias, status: item })}
            >
              <Status
              user={item.alias}
              status={item}
              />
            </TouchableOpacity>
          );
        }}
      />
    </>
  );
};

FeedScreen.navigationOptions = {
  title: 'Feeds',
  tabBarIcon: <FontAwesome name="th-list" size={20} />
};

// const styles = StyleSheet.create({});

export default FeedScreen;
