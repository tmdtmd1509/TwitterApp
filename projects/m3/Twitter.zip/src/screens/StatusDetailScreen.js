import React, { useContext } from 'react';
import { View, StyleSheet, Text } from 'react-native';
// import { Context as StatusContext } from '../context/StatusContext';
import Status from '../components/Status'


const StatusDetailScreen = ({ navigation }) => {
  const status = navigation.getParam('status');
  const user = navigation.getParam('user');

  return (
    <>
      <Status
        user={user}
        status={status}
      />
    </>
  );
};

const styles = StyleSheet.create({
  map: {
    height: 300
  }
});

export default StatusDetailScreen;
